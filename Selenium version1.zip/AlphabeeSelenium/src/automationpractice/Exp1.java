package automationpractice;

import java.util.List;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;

public class Exp1 {

	public static void main(String[] args) throws Exception {
	WebDriver driver = new ChromeDriver();
	driver.get("https://itera-qa.azurewebsites.net/home/automation");
	driver.manage().window().maximize();
	Thread.sleep(2000);
	driver.findElement(By.id("name")).sendKeys("Naveen");
	driver.findElement(By.id("phone")).sendKeys("8686957268");
	driver.findElement(By.id("email")).sendKeys("naveen@gmail.com");
    driver.findElement(By.id("password")).sendKeys("Naveen@123");
    driver.findElement(By.id("address")).sendKeys("Malkajgiri");
	driver.findElement(By.name("submit")).click();
	driver.findElement(By.id("male")).click();
	 WebElement radio=driver.findElement(By.id("monday"));
	 radio.click();
	 
	 //dropdown
	 List <WebElement> l=driver.findElements(By.xpath("//*[@class=\"custom-select\"]/option"));
	 
	 for(int i=0;  i<l.size(); i++)
	 {
	    l.get(i).click();
	}
	 
	 WebElement e= driver.findElement(By.xpath("//input[contains(@class,\"custom-file\")]"));
	 e.sendKeys("D:\\Naveen\\pictures\\Naveen.jpeg");
	}
}
