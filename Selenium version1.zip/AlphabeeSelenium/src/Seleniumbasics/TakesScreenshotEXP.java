package Seleniumbasics;

import java.io.File;
import java.io.IOException;

import org.openqa.selenium.By;
import org.openqa.selenium.OutputType;
import org.openqa.selenium.TakesScreenshot;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.chrome.ChromeOptions;
import org.openqa.selenium.io.FileHandler;

public class TakesScreenshotEXP {

	public static void main(String[] args) throws InterruptedException, IOException {
		
		ChromeOptions co=new  ChromeOptions();
		co.setHeadless(true);
		
		WebDriver driver=new ChromeDriver(); 
		driver.get("https://www.spicejet.com");
		driver.manage().window().maximize();
		Thread.sleep(2000);
		
		TakesScreenshot ts=(TakesScreenshot)driver;
		
		File src=ts.getScreenshotAs(OutputType.FILE);
		
		File dest= new File("D:\\error.bmp");
		FileHandler.copy(src, dest);
		Thread.sleep(2000);
		
		driver.quit();  
	}

}
