package Seleniumbasics;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;

public class HandlingWindows {
	
	public static void main(String[] args) throws Exception
	{
		
	WebDriver driver =new ChromeDriver();
	driver.get("https://www.nopcommerce.com/en/demo");
	driver.manage().window().maximize();
	Thread.sleep(2000);
	
	WebElement adminlink=driver.findElement(By.xpath("//*[@class=\"button-text\"]"));
	  adminlink.click();
	  Thread.sleep(2000);
	  
	  WebElement username=driver.findElement(By.name("//*[@class=\"email valid\"]"));
	  username.sendKeys("jcjdjcjdjv");
	  Thread.sleep(2000);
	  driver.quit();
	}
}
