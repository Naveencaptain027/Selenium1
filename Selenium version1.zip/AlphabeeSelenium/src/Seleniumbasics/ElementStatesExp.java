package Seleniumbasics;

import java.awt.Checkbox;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;

public class ElementStatesExp {

	public static void main(String[] args) throws InterruptedException {
		ElementStatesExp obj=new ElementStatesExp();
     obj.VerifyActiveElementState();
	}
		public void VerifyActiveElementState() throws InterruptedException
		{
		 WebDriver driver= new ChromeDriver();
		 driver.get("https://www.w3schools.com/tags/tryit.asp?filename=tryhtml_input_disabled");
		 driver.manage().window().maximize();
		 Thread.sleep(2000);
		 driver.switchTo().frame("iframeResult");
		 WebElement lastname=driver.findElement(By.id("lname"));
		 //verify that element is interactable or not
		 if(lastname.isEnabled())
		 {
			 lastname.sendKeys("pass");
		}
		 else
			 {
			 System.out.println("operation is skipped and element is disabled");
			 }
		
		 Thread.sleep(2000);
		 driver.quit();
			 }

public void VerifyElementIsSelected() throws InterruptedException
{
 WebDriver driver= new ChromeDriver();
 driver.get("https://www.w3schools.com/tags/tryit.asp?filename=tryhtml_input_disabled");
 driver.manage().window().maximize();
 Thread.sleep(2000);
 driver.switchTo().frame("iframeResult");
 WebElement Checkbox1=driver.findElement(By.name("vehicle1"));
 Checkbox1.click();
 WebElement Checkbox2=driver.findElement(By.name("vehicle1"));
 Checkbox2.click();
 WebElement Checkbox3=driver.findElement(By.name("vehicle1"));
 Checkbox3.click();
 Thread.sleep(2000);
 driver.quit();
}
}
